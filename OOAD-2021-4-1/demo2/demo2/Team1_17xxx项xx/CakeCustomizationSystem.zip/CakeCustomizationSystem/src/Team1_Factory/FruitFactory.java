package Team1_Factory;

import Team1_SimpleFactory.FruityCake;
import Team1_SimpleFactory.GrapeCake;
import Team1_SimpleFactory.StrawberryCake;

public class FruitFactory implements Factory{
//具体产品一
private String cakeType;
	
	public FruitFactory(String cakeType){
		this.cakeType = cakeType;
	}
	
	public void createCake(){
		try{
			if (cakeType.equals("草莓水果")){
				FruityCake strawberryCake = new StrawberryCake();
				strawberryCake.show();
			}
			else if (cakeType.equals("葡萄水果")) {
				FruityCake grapeCake = new GrapeCake();
				grapeCake.show();
			}
		} 
		catch (Exception e){  
            System.out.println("制作"+cakeType+"蛋糕失败");  
        }		
    }
}
