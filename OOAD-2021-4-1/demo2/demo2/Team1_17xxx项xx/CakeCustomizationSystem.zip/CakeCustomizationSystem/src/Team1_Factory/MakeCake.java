package Team1_Factory;

public interface MakeCake {
//制作蛋糕构造者
}
