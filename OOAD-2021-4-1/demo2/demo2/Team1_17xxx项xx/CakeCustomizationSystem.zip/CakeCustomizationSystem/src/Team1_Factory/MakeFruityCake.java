package Team1_Factory;

public class MakeFruityCake implements MakeCake{
	//制作蛋糕构造者二
private String cakeType;
	
	public MakeFruityCake(String cakeType){
		this.cakeType = cakeType;
}

public FruitFactory makeFruityCake(){
		return new FruitFactory(cakeType);
}
}
