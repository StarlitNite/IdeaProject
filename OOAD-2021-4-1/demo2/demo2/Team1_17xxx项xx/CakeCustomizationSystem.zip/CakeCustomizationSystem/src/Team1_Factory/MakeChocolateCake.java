package Team1_Factory;

public class MakeChocolateCake implements MakeCake{
	//制作蛋糕构造者一
private String cakeType;
	
	public MakeChocolateCake(String cakeType){
		this.cakeType = cakeType;
	}
	
	public ChocolateFactory makeChocolateCake(){
		return new ChocolateFactory(cakeType);
}
}
