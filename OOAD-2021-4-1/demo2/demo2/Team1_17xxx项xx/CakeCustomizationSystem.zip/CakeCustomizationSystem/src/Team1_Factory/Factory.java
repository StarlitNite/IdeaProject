package Team1_Factory;

public interface Factory {
	//抽象产品
	public void createCake();
}
