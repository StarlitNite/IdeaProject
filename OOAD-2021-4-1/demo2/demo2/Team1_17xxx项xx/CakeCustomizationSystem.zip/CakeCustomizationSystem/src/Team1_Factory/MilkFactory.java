package Team1_Factory;

import Team1_SimpleFactory.DoubleMilkCake;
import Team1_SimpleFactory.MilkCake;
import Team1_SimpleFactory.SweetMilkCake;

public class MilkFactory implements Factory{
//具体产品二
private String cakeType;
	
	public MilkFactory(String cakeType){
		this.cakeType = cakeType;
	}
	
	public void createCake(){
		try{
			if (cakeType.equals("双层鲜奶")){
				MilkCake doubleMilkCake = new DoubleMilkCake();
				doubleMilkCake.show();				
			}
			else if (cakeType.equals("甜奶")) {
				MilkCake sweetMilkCake = new SweetMilkCake();
				sweetMilkCake.show();
			}
		} 
		catch (Exception e){  
            System.out.println("制作"+cakeType+"蛋糕失败");  
        } 
    }
}
