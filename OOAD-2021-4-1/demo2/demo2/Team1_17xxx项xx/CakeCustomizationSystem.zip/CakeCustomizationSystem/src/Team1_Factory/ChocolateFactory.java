package Team1_Factory;

import Team1_SimpleFactory.ChocolateCake;
import Team1_SimpleFactory.DarkChocolateCake;
import Team1_SimpleFactory.MilkChocolateCake;

public class ChocolateFactory implements Factory{
//具体产品三
private String cakeType;
	
	public ChocolateFactory(String cakeType){
		this.cakeType = cakeType ;
	}
	
	public void createCake(){
		try{
			if (cakeType.equals("牛奶巧克力")){
				ChocolateCake milkChocolateCake = new MilkChocolateCake();
				milkChocolateCake.show();
			}
			else if (cakeType.equals("黑巧克力")) {
				ChocolateCake darkChocolateCake = new DarkChocolateCake();
				darkChocolateCake.show();
			}
		} 
		catch (Exception e){  
            System.out.println("制作"+cakeType+"蛋糕失败");  
        }		
    }
}
