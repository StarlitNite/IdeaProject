package Team1_Strategy;

public interface DiscountStyle {
	//折扣接口
	public double disCount(double price,double m);
}
