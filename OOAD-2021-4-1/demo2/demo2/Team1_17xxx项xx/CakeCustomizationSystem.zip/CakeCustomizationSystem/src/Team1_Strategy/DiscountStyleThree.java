package Team1_Strategy;

public class DiscountStyleThree implements DiscountStyle{
	//折扣方式三
	public double disCount(double price,double m) {
		price = price * m/10;
		return price;
	}
}
