package Team1_Strategy;

public class DiscountStyleOne implements DiscountStyle{
	//折扣方式一
	public double disCount(double price,double m) {
		return price;
	}
}
