package Team1_Strategy;

public class DiscountStyleTwo implements DiscountStyle{
	//折扣方式二
	public double disCount(double price,double m) {
		price = price - m;
		return price;
	}
}
