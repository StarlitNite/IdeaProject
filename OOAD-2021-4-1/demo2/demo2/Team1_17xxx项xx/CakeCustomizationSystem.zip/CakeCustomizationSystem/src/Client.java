import Team1_Observer.CakeShop;
import Team1_Observer.EastVilla;
import Team1_Observer.WestVilla;
import Team1_Proxy.OrderCall;
import Team1_Strategy.DiscountStyleThree;
import Team1_Strategy.OrderCake;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
CakeShop starCakeShop = CakeShop.getCakeShop();
		new WestVilla(starCakeShop, "草莓水果");		
		starCakeShop.getNewName("西13");
		starCakeShop.notifyCustomer();	
		OrderCake cake = new OrderCake();
		System.out.println("今日促销一律8折优惠");	
		cake.setM(8);
		cake.setStyle(new DiscountStyleThree());
		cake.setPrice(80) ;
		System.out.println("本次订购成功完成，需要支付的金额为"+cake.getMoney(cake.getPrice(),cake.getM())+"，原价80");
		OrderCall orderCall = new OrderCall();
		orderCall.orderCake("西13");
		System.out.println("=================================");
		
		new EastVilla(starCakeShop, "甜奶");
		starCakeShop.getNewName("东18");
		starCakeShop.notifyCustomer();	
		System.out.println("=================================");
		
	}
}
