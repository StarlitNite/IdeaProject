package Team1_Observer;

public interface Shop {
	//主题
	public void addCustomer(Customer o);
	public void deleteCustomer(Customer o);
	public void notifyCustomer();
}
