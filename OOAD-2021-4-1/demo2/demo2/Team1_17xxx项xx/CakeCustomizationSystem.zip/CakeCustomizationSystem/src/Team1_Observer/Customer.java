package Team1_Observer;

public interface Customer {
	//观察者
	public void orderCake(String name);
}
