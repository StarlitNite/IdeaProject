package Team1_SimpleFactory;

public class StrawberryCake implements FruityCake{
	public void show() {
		System.out.println("生产了一个草莓水果蛋糕");
	}
}
