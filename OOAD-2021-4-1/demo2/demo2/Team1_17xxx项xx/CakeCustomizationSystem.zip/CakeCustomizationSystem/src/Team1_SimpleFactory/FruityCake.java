package Team1_SimpleFactory;

public interface FruityCake {
	//水果蛋糕
	public void show();
}
