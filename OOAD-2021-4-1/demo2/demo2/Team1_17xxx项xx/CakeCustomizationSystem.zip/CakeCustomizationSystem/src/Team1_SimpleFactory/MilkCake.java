package Team1_SimpleFactory;

public interface MilkCake {
	public void show();
}
