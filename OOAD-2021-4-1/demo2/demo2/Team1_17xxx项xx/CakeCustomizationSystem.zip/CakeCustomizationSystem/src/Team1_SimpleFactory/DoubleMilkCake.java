package Team1_SimpleFactory;

public class DoubleMilkCake implements MilkCake{
	public void show() {
		System.out.println("生产了一个双层鲜奶蛋糕");
	}
}
