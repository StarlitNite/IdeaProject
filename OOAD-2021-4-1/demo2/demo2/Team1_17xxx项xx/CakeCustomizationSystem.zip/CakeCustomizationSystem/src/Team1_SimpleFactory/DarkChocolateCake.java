package Team1_SimpleFactory;

public class DarkChocolateCake implements ChocolateCake{
	public void show() {
		System.out.println("生产了一个黑巧克力蛋糕");
	}
}
