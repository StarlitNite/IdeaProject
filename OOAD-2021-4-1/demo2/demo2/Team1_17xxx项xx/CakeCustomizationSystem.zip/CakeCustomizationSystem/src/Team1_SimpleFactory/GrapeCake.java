package Team1_SimpleFactory;

public class GrapeCake implements FruityCake{
	public void show() {
		System.out.println("生产了一个葡萄水果蛋糕");
	}
}
