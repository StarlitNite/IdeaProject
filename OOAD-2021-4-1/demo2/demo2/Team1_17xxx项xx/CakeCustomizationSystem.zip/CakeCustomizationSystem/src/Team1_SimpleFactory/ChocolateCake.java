package Team1_SimpleFactory;

public interface ChocolateCake {
	public void show();
}
