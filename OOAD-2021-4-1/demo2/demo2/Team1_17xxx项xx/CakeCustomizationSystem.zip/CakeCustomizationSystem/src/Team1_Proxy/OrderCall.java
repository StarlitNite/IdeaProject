package Team1_Proxy;

import Team1_Observer.Customer;

public class OrderCall implements Customer{
	public void orderCake(String name) {
		System.out.println(name+"蛋糕已做好，可以来领取");
	}
}
