package qiaojiemoshi_yunshufangshi;

public class ZtoTransport extends Company {

	@Override
	public String print() {
		// TODO Auto-generated method stub
		return transportType.showType("��ͨ");
	}

}
