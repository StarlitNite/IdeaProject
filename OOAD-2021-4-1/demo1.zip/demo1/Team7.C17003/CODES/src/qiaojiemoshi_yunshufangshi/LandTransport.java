package qiaojiemoshi_yunshufangshi;

public class LandTransport implements TransportType {

	@Override
	public String showType(String company) {
		// TODO Auto-generated method stub
		return company+"��½��";
	}

}
