package qiaojiemoshi_yunshufangshi;

public class SfTransport extends Company {

	@Override
	public String print() {
		// TODO Auto-generated method stub
		return transportType.showType("˳��");
	}

}
