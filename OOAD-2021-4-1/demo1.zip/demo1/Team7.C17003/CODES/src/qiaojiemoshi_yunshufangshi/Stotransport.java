package qiaojiemoshi_yunshufangshi;

public class Stotransport extends Company {

	@Override
	public String print() {
		// TODO Auto-generated method stub
		return transportType.showType("��ͨ");
	}

}
