package qiaojiemoshi_yunshufangshi;

public class AirTransport implements TransportType {

	@Override
	public String showType(String company) {
		// TODO Auto-generated method stub
		return company+"�Ŀ���";
	}

}
