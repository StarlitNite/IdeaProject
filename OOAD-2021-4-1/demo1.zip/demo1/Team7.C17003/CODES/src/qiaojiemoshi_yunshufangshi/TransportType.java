package qiaojiemoshi_yunshufangshi;

public interface TransportType {
	public String showType(String company);
}
