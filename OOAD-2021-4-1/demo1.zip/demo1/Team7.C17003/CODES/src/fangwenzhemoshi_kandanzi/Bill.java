package fangwenzhemoshi_kandanzi;

public interface Bill {
	String accept(AccountBookViewer viewer);
}
