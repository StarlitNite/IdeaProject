package celuemoshi_huiyuanzhi;

public class DiamondUser extends User {
	public DiamondUser() {
		super.setMember(new DiamondMember());
	}
}
