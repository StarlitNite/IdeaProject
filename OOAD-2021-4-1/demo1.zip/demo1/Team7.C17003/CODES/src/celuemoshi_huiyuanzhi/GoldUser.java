package celuemoshi_huiyuanzhi;

public class GoldUser extends User {

	public GoldUser() {
		super.setMember(new GoldMember());
	}

}
