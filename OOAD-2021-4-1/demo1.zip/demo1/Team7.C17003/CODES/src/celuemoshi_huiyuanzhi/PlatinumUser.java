package celuemoshi_huiyuanzhi;

public class PlatinumUser extends User {
	public PlatinumUser() {
		super.setMember(new PlatinumMember());
	}
}
