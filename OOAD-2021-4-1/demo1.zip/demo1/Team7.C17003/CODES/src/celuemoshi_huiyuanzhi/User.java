package celuemoshi_huiyuanzhi;

public class User {
    private Member member;
    
    public void setMember(Member member) {
    	this.member = member;
    }
    public Member getMember() {
    	return this.member;
    }
}
