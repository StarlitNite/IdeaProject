package celuemoshi_huiyuanzhi;

public interface Member {
	public double discount();
	public void setDiscount(double discount);
	public double getDiscount();
}
