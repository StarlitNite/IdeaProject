package zhuangshizhemoshi_dingdan;

public abstract class FillDecorator extends Form {
	public abstract void fill();
	public abstract String getXingxi();
	public abstract void setXingxi(String xingxi);
}
