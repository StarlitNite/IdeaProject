package zhuangshizhemoshi_dingdan;

public abstract class Form {
	public abstract void fill();
	public abstract String getXingxi();
	public abstract void setXingxi(String xingxi);
}
