package gongchangmoshi_box;

public interface Box {
	public abstract String play();
}
