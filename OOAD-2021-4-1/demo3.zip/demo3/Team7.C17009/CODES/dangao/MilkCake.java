package net.xsl.ordercake.product;

public interface MilkCake {
void show();
}
