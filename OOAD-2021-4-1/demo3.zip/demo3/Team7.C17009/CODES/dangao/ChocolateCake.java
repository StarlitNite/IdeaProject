package net.xsl.ordercake.product;

public interface ChocolateCake {
void show();
}
