package net.xsl.ordercake.product;

public class StrawberryCake implements FruityCake{
	public void show() {
		System.out.println("生产了一个草莓水果蛋糕");
	}
}
