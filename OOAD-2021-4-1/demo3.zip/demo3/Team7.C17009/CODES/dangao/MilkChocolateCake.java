package net.xsl.ordercake.product;

public class MilkChocolateCake implements ChocolateCake{
	public void show() {
		System.out.println("生产了一个牛奶巧克力蛋糕");
	}
}
