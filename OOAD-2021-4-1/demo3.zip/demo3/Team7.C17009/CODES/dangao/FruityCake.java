package net.xsl.ordercake.product;

public interface FruityCake {
	public void show();
}
