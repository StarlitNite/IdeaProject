package net.xsl.ordercake.discount;

public interface DiscountStyle {
public double disCount(double price,double m);
}
