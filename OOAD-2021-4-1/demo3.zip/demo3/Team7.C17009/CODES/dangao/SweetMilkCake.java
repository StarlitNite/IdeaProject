package net.xsl.ordercake.product;

public class SweetMilkCake  implements MilkCake{
	public void show() {
		System.out.println("生产了一个甜奶蛋糕");
	}
}
