package net.xsl.ordercake.discount;

public class DiscountStyleOne implements DiscountStyle{
public double disCount(double price,double m) {
	return price;
}
}
