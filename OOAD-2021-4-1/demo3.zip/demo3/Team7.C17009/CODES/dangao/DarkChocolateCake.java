package net.xsl.ordercake.product;

public class DarkChocolateCake implements ChocolateCake{
	public void show() {
		System.out.println("生产了一个黑巧克力蛋糕");
	}
}
