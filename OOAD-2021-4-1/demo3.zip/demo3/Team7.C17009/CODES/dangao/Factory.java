package net.xsl.ordercake.product;

public interface Factory {
	public void createCake();
}
