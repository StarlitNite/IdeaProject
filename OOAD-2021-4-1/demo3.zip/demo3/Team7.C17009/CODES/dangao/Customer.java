package net.xsl.ordercake.order;

public interface Customer {
	public void orderCake(String name);
}
