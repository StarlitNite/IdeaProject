package net.xsl.ordercake.creator;

public interface MakeCake {
}
