package net.xsl.ordercake.product;

public class DoubleMilkCake implements MilkCake{
	public void show() {
		System.out.println("生产了一个双层鲜奶蛋糕");
	}
}
