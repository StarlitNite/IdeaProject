package decorator;

public interface Beverage {
 
	public abstract double cost();
	public abstract String getDiscription();
}
 
